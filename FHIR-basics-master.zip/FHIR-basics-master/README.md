## Patient
Creación del recurso paciente con algunos parámetros. 

## Base 
Lectura y escritura de recursos en el servidor público de HAPI FHIR. 

## Workflow
Desde acá se corre el código. 
